Link to github:

https://github.com/juliorenner/computacao-grafica/tree/master/ObjRenderer